This is the first megabase from the human chromosome 20.
It is phased data for 4 subjects from the 1000 Genomes project.

Reference:
Nature Vol 467, Issue 7319 2010
A map of human genome variation from population-scale sequencing
doi: 10.1038/nature09534
